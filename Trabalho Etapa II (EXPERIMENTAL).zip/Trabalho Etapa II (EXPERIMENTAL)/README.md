# Trabalho Experimental de Controle Digital

## Conteudo da pasta
- Ensaios_Sistema [Pasta referente aos dados coletados do motor, sendo o tratamento dos dados realizado em excel]
- Leitura_velocidade [Pasta com o programa para arduino para controle do rpm do motor]
- Relatorio_Jupiter [Pasta contento o relatório em jupyter e demais imagens usadas nele]
- Enunciado [Enunciado do Trabalho pratico]